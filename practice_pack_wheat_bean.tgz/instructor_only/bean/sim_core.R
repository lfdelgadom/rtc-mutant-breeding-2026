# sim_core.R. Common steps for the mutant trial simulations (INSTRUCTOR FILE).
# 1) genetic values of parents and mutants, 2) plot errors (FieldSimR), 3) phenotypes (FieldSimR).
suppressMessages({library(FieldSimR); library(MASS)})

sim_core <- function(cfg) {
  with(cfg, {
    nt <- length(traits); ne <- nrow(envs)
    n_mut <- length(parents) * n_per_parent
    mut_id <- sprintf("M%03d", seq_len(n_mut))
    mut_parent <- rep(parents, each = n_per_parent)
    mut_dose <- rep(doses, length.out = n_mut)
    ids <- c(parents, mut_id); ng <- length(ids)
    K <- kronecker(Rt, Re)
    sd_vec <- function(base) as.vector(sapply(base, function(b) b * env_scale))   # trait-major
    draw <- function(n, base) sweep(mvrnorm(n, rep(0, nt * ne), K), 2, sd_vec(base), "*")
    parent_eff <- draw(length(parents), sd_parent)
    parent_eff <- sweep(parent_eff, 2, colMeans(parent_eff))                  # centre, so that the means stay close to mu
    mut_eff <- draw(n_mut, sd_mut)
    ds <- dose_scale[as.character(mut_dose)]
    big <- rbinom(n_mut, 1, p_big) * 1.5 + 1
    mut_eff <- mut_eff * ds * big
    steps <- (mut_dose - min(doses)) / (max(doses) - min(doses)) * 2           # 0, 1, 2 for three doses
    shift <- t(sapply(steps, function(k) k * loss))[, rep(1:nt, each = ne), drop = FALSE] * rep(sd_vec(sd_mut), each = n_mut)
    mut_eff <- mut_eff + matrix(shift, n_mut)
    gv_mat <- rbind(parent_eff, parent_eff[match(mut_parent, parents), ] + mut_eff)
    colnames(gv_mat) <- paste0(rep(traits, each = ne), "_E", rep(1:ne, nt)); rownames(gv_mat) <- ids
    gv_true <- sweep(gv_mat, 2, as.vector(t(mu)), "+")

    H2 <- as.vector(sapply(H2_base, function(h) h * H2_env))
    vg <- apply(gv_true, 2, var)
    varR <- vg / H2 - vg
    ps <- rep(prop_spatial_env, nt); pe <- rep(prop_ext_env, nt)
    ScorR <- rand_cor_mat(nt, min.cor = 0, max.cor = 0.5, pos.def = TRUE)
    EcorR <- rand_cor_mat(nt, min.cor = 0, max.cor = 0.5, pos.def = TRUE)
    RcorR <- rand_cor_mat(nt, min.cor = 0, max.cor = 0.4, pos.def = TRUE)
    err <- field_trial_error(ntraits = nt, nenvs = ne, nblocks = nblocks, block.dir = "col",
                             ncols = ncols, nrows = nrows, plot.length = 1.2, plot.width = 0.4,
                             varR = varR, ScorR = ScorR, EcorR = EcorR, RcorR = RcorR,
                             spatial.model = "Bivariate", prop.spatial = ps,
                             ext.ord = "zig-zag", ext.dir = "row", prop.ext = pe, return.effects = TRUE)
    gv_df <- do.call(rbind, lapply(1:ne, function(e) {
      dd <- data.frame(env = e, id = factor(ids, levels = ids), rep = 1)
      for (t in 1:nt) dd[[paste0("gv.Trait", t)]] <- gv_true[, (t - 1) * ne + e]
      dd
    }))
    design_df <- NULL
    if (!is.null(design_nreps)) {
      design_df <- do.call(rbind, lapply(1:ne, function(e) data.frame(env = e, id = ids, nreps = design_nreps(e, ids, nblocks[e]))))
    } else {
      gv_df <- do.call(rbind, lapply(1:ne, function(e) do.call(rbind, lapply(1:nblocks[e], function(b) { x <- gv_df[gv_df$env == e, ]; x$rep <- b; x }))))
    }
    gv_df$env <- factor(gv_df$env); gv_df$rep <- factor(gv_df$rep)
    ph <- make_phenotypes(gv_df, err$error.df, design.df = design_df, randomise = TRUE)
    for (t in 1:nt) names(ph)[names(ph) == paste0("y.Trait", t)] <- traits[t]
    ph <- ph[order(ph$env, ph$block, ph$col, ph$row), ]
    list(ph = ph, ids = ids, mut_id = mut_id, mut_parent = mut_parent, mut_dose = mut_dose,
         gv_true = gv_true, H2 = H2, vg = vg, varR = varR, ps = ps, pe = pe, nt = nt, ne = ne, ng = ng)
  })
}

# Basic table with the design columns (environment, block, row, column, plot, genotype, parent, dose)
make_table <- function(res, cfg) {
  ph <- res$ph; e <- as.integer(as.character(ph$env))
  d <- cfg$envs[e, setdiff(names(cfg$envs), "env"), drop = FALSE]
  rownames(d) <- NULL
  d$block <- paste0("B", ph$block); d$row <- as.integer(as.character(ph$row)); d$column <- as.integer(as.character(ph$col))
  d$genotype <- as.character(ph$id)
  d$plot <- ave(seq_len(nrow(d)), d$environment, FUN = seq_along) + 100 * match(d$environment, cfg$envs$environment)
  d$parent <- ifelse(d$genotype %in% cfg$parents, d$genotype, res$mut_parent[match(d$genotype, res$mut_id)])
  d$type <- ifelse(d$genotype %in% cfg$parents, "parent", "mutant")
  d$dose_Gy <- ifelse(d$type == "parent", 0, res$mut_dose[match(d$genotype, res$mut_id)])
  cbind(d, ph[, cfg$traits, drop = FALSE])
}

# Keeps a log of every problem that is inserted
new_log <- function() { env <- new.env(); env$rows <- list(); env }
log_add <- function(L, d, idx, trait, problem, old) {
  if (length(idx)) L$rows[[length(L$rows) + 1]] <- data.frame(plot = d$plot[idx], environment = d$environment[idx], genotype = d$genotype[idx],
                                                              trait = trait, problem = problem, true_value = old, stringsAsFactors = FALSE)
}
