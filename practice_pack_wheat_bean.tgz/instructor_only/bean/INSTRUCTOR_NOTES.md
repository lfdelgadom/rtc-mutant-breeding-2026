# Common bean mutant trials. Instructor notes (do not share with participants)

Files
- `simulate_bean.R` (needs `sim_core.R` in the same folder): the full simulation. Fixed seed, same file every time.
- `answer_key/`: `true_genetic_values.csv`, `problems_inserted.csv`, `simulation_parameters.csv`, `genotype_list.csv` (parent, dose, seed coat colour).

What is in the data
- 3 parents + 81 mutants (27 per parent), doses 100, 200, 300 Gy. 3 environments (irrigated, terminal drought, rainfed at a second site).
- RCBD, 3 blocks of 7 x 12 plots, every line once per block. 756 plots.
- Genetic values: parent effect + mutation effect (larger with dose, 10% large effects, a higher dose lowers pods, seed weight and yield a little).
- Drought: lower means (yield about 1100 vs 2300 irrigated), more error. Observed yield correlation between environments about 0.4 to 0.5.
- Observed plot-level heritability (one environment, lmer): flowering 0.56 to 0.73, maturity 0.64 to 0.79, pods 0.41 to 0.51, seed weight 0.51 to 0.71, yield 0.32 to 0.49.
- Seed coat colour: parents cream, red, black. About 6, 10 and 18% of the mutants (100, 200, 300 Gy) changed colour (white, brown, red mottled, cream or black).
- Problems: 6 plots in Site1_drought with crop failure (pods 0 and yield 0, REAL zeros), 2% plots without emergence (NA), goat damage in Site2_rainfed block B3 (rows 1 to 2, columns 25 to 30, yield x0.5 and pods x0.6, REAL), 3% values not recorded per trait,
  and 20 outliers (yield in t/ha: 4; seed weight x10: 4; pods x10: 4; flowering date +30: 4; maturity date +30: 4).

Suggested exercises
1. Find the problems and compare with `problems_inserted.csv`. Discuss: zeros and goat damage, remove or keep?
2. One environment: RCBD mixed model, then spatial model. Heritability (compare with the key).
3. MET and G x E. Which mutants are stable, which are good only under drought?
4. Mutants against parents, effect of the dose.
5. Selection index with early maturity, and the colour classes of the selected lines (market preference).

Tested with FieldSimR 1.4.2 (GitHub). Do not commit this folder to a public repository.
