# =====================================================================
# Simulated multi-environment trials of common bean mutants (M6 lines)
# RTC RER5030. INSTRUCTOR FILE, do not give to participants (it contains the answers).
# Needs sim_core.R in the same folder, and the packages FieldSimR and MASS.
# Run: source("simulate_bean.R")
# =====================================================================
source("sim_core.R")
set.seed(20261120)
dir.create("public", showWarnings = FALSE); dir.create("answer_key", showWarnings = FALSE)

traits <- c("days_to_flowering", "days_to_maturity", "pods_per_plant", "hundred_seed_weight_g", "seed_yield_kg_ha")
nt <- length(traits)
envs <- data.frame(
  env = 1:3,
  environment = c("Site1_irrigated", "Site1_drought", "Site2_rainfed"),
  location = c("Site1", "Site1", "Site2"),
  water = c("Irrigated", "Terminal drought", "Rainfed"))

cfg <- list(
  traits = traits, envs = envs,
  mu = rbind(days_to_flowering = c(38, 36, 40), days_to_maturity = c(85, 77, 90),
             pods_per_plant = c(14, 8, 11), hundred_seed_weight_g = c(24, 20, 22),
             seed_yield_kg_ha = c(2400, 1200, 1800)),
  sd_parent = c(1.5, 2.5, 2, 2.5, 250), sd_mut = c(1.2, 2, 1.5, 1.8, 200), env_scale = c(1, 1.3, 1.1),
  Rt = matrix(c(1, .6, .0, .1, -.1,   .6, 1, .1, .1, 0,   0, .1, 1, -.4, .6,   .1, .1, -.4, 1, .3,   -.1, 0, .6, .3, 1), 5, 5, byrow = TRUE),
  Re = matrix(c(1, .5, .7,   .5, 1, .4,   .7, .4, 1), 3, 3, byrow = TRUE),
  parents = paste0("Parent_", LETTERS[1:3]), n_per_parent = 27,
  doses = c(100, 200, 300), dose_scale = c(`100` = 0.7, `200` = 1, `300` = 1.4),
  loss = c(0, 0, -0.2, -0.1, -0.25), p_big = 0.10,
  H2_base = c(0.80, 0.80, 0.50, 0.70, 0.45), H2_env = c(1, 0.80, 0.90),
  prop_spatial_env = c(0.25, 0.40, 0.30), prop_ext_env = c(0.10, 0.15, 0.10),
  nblocks = c(3, 3, 3), ncols = rep(36, 3), nrows = 7,          # 3 blocks of 7 x 12 = 84 plots, every line once per block
  design_nreps = NULL)
res <- sim_core(cfg)
d <- make_table(res, cfg)

# ---------------------------------------------------------------- Qualitative trait: seed coat colour (per genotype)
col_parent <- c(Parent_A = "cream", Parent_B = "red", Parent_C = "black")
n_mut <- length(res$mut_id)
p_change <- c(`100` = 0.06, `200` = 0.10, `300` = 0.18)[as.character(res$mut_dose)]
colr <- col_parent[res$mut_parent]
chg <- runif(n_mut) < p_change
colr[chg] <- sample(c("white", "brown", "red mottled", "cream", "black")[1:5], sum(chg), replace = TRUE)
col_all <- c(col_parent, setNames(colr, res$mut_id))
d$seed_coat_colour <- col_all[d$genotype]

# ---------------------------------------------------------------- Round like a field book
d$days_to_flowering <- round(d$days_to_flowering); d$days_to_maturity <- round(d$days_to_maturity)
d$pods_per_plant <- round(pmax(1, d$pods_per_plant), 1); d$hundred_seed_weight_g <- round(pmax(6, d$hundred_seed_weight_g), 1)
d$seed_yield_kg_ha <- round(pmax(80, d$seed_yield_kg_ha))
clean <- d

# ---------------------------------------------------------------- Problems
L <- new_log(); n <- nrow(d)
# total crop failure in the drought trial: REAL zeros (not missing)
fail <- sample(which(d$environment == "Site1_drought"), 6)
for (tr in c("pods_per_plant", "seed_yield_kg_ha")) { log_add(L, d, fail, tr, "crop failure, real zero (not missing)", d[[tr]][fail]); d[[tr]][fail] <- 0 }
dead <- setdiff(sample(n, round(0.02 * n)), fail)
for (tr in traits) { log_add(L, d, dead, tr, "no emergence, plot lost", d[[tr]][dead]); d[[tr]][dead] <- NA }
# goats in Site2, block B3: real damage (yield x0.5, pods x0.6)
goat <- setdiff(which(d$environment == "Site2_rainfed" & d$block == "B3" & d$row %in% 1:2 & d$column %in% 25:30), c(dead, fail))
log_add(L, d, goat, "seed_yield_kg_ha", "animal damage (real effect, x0.5)", d$seed_yield_kg_ha[goat]); d$seed_yield_kg_ha[goat] <- round(d$seed_yield_kg_ha[goat] * 0.5)
log_add(L, d, goat, "pods_per_plant", "animal damage (real effect, x0.6)", d$pods_per_plant[goat]); d$pods_per_plant[goat] <- round(d$pods_per_plant[goat] * 0.6, 1)
for (tr in traits) {
  ok <- which(!is.na(d[[tr]])); idx <- sample(ok, round(0.03 * length(ok)))
  log_add(L, d, idx, tr, "value not recorded", d[[tr]][idx]); d[[tr]][idx] <- NA
}
out_one <- function(tr, kind, k) {
  ok <- which(!is.na(d[[tr]]) & d[[tr]] > 0); idx <- sample(ok, k); old <- d[[tr]][idx]
  d[[tr]][idx] <<- switch(kind, ten = old * 10, tenth = old / 10, t = old / 1000, plus = old + 30)
  log_add(L, d, idx, tr, paste("outlier,", kind), old)
}
out_one("seed_yield_kg_ha", "t", 4)               # 2.4 (t/ha) instead of 2400 (kg/ha)
out_one("hundred_seed_weight_g", "ten", 4)        # 240 instead of 24
out_one("pods_per_plant", "ten", 4)
out_one("days_to_flowering", "plus", 4)           # wrong date
out_one("days_to_maturity", "plus", 4)
d$seed_yield_kg_ha <- round(d$seed_yield_kg_ha, 3)

# ---------------------------------------------------------------- Save
cols <- c("environment", "location", "water", "plot", "block", "row", "column", "genotype", "type", "parent",
          "dose_Gy", "seed_coat_colour", traits)
write.csv(d[, cols], "public/bean_mutant_trials.csv", row.names = FALSE, na = "")
logdf <- do.call(rbind, L$rows)
write.csv(logdf, "answer_key/problems_inserted.csv", row.names = FALSE)
ids <- res$ids; ne <- res$ne; ng <- res$ng
write.csv(data.frame(genotype = rep(ids, times = nt * ne), trait = rep(traits, each = ng * ne),
                     environment = rep(rep(envs$environment, each = ng), times = nt), true_genetic_value = as.vector(res$gv_true)),
          "answer_key/true_genetic_values.csv", row.names = FALSE)
write.csv(data.frame(genotype = ids, parent = c(cfg$parents, res$mut_parent), dose_Gy = c(rep(0, 3), res$mut_dose),
                     seed_coat_colour = col_all[ids]), "answer_key/genotype_list.csv", row.names = FALSE)
write.csv(data.frame(trait = rep(traits, each = ne), environment = rep(envs$environment, nt), target_plot_H2 = res$H2,
                     genetic_variance = res$vg, error_variance = res$varR, prop_spatial = res$ps, prop_extraneous = res$pe),
          "answer_key/simulation_parameters.csv", row.names = FALSE)
saveRDS(clean, "answer_key/clean_table.rds")
message("Done. Rows: ", nrow(d), ". Problems: ", nrow(logdf))
