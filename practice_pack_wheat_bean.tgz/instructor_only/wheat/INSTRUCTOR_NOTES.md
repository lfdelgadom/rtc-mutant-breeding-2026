# Durum wheat mutant trials. Instructor notes (do not share with participants)

Files
- `simulate_wheat.R` (needs `sim_core.R` in the same folder): the full simulation. Fixed seed, same file every time.
- `answer_key/true_genetic_values.csv`: true genetic value of each line, trait and environment (before plot error).
- `answer_key/problems_inserted.csv`: every missing value, hail plot and outlier, with the true value.
- `answer_key/simulation_parameters.csv`: target plot-level heritability, variances, share of spatial and extraneous error.
- `answer_key/genotype_list.csv`: parent, dose and awn type of each line.

What is in the data
- 3 parents + 102 mutants (34 per parent), doses 150, 200, 250 Gy. 4 environments (2 locations x 2 years, the 2025 year is dry).
- 2 blocks of 8 x 8 plots. Partially replicated: 30 mutants twice, 62 once, 10 not tested (different ones in each environment). Parents in both blocks. 512 plots.
- Genetic values: parent effect + mutation effect (larger with dose, 10% large effects, a higher dose lowers height, spikes, kernel weight and yield a little).
- Dry years: lower means, lower heritability, more error. Observed yield correlation between environments is about 0.1 to 0.3 (strong G x E).
- Observed plot-level heritability (one environment, lmer): heading 0.5 to 0.8, height 0.2 to 0.9, spikes 0.2 to 0.4, kernel weight 0.5 to 0.7, yield 0.2 to 0.5.
- Awn type: 97 awned, 5 short awned, 3 awnless lines (more changes at higher dose). Lodging score from plant height + storm effect in North_2024.
- Problems: 2% plots without emergence (all traits NA), 3% values not recorded per trait, hail in South_2025 block B2 (rows 1 to 3, columns 9 to 12, yield x0.6 and spikes x0.75, REAL effect, not an error),
  and 22 outliers (yield in kg/ha: 4; kernel weight x10: 5; plant height x10: 3; heading date +25 days: 6; spikes /10: 4).

Suggested exercises
1. Find the problems and compare with `problems_inserted.csv`. Discuss: hail plots stay or go?
2. One environment, unbalanced design: mixed model with block, then spatial model. Heritability (compare with the key).
3. MET: G x E, stable and dry-year lines.
4. Mutants against parents, effect of dose.
5. Lodging as an ordinal trait (for example a cumulative link model), not as a mean.
6. Selection index and awn type of the selected lines.

Tested with FieldSimR 1.4.2 (GitHub). Do not commit this folder to a public repository.
