# =====================================================================
# Simulated multi-environment trials of durum wheat mutants (M5 lines)
# RTC RER5030. INSTRUCTOR FILE, do not give to participants (it contains the answers).
# Needs sim_core.R in the same folder, and the packages FieldSimR and MASS.
# Run: source("simulate_wheat.R")
# =====================================================================
source("sim_core.R")
set.seed(20261118)
dir.create("public", showWarnings = FALSE); dir.create("answer_key", showWarnings = FALSE)

traits <- c("days_to_heading", "plant_height_cm", "spikes_per_m2", "thousand_kernel_weight_g", "grain_yield_t_ha")
nt <- length(traits)
envs <- data.frame(
  env = 1:4,
  environment = c("North_2024", "South_2024", "North_2025", "South_2025"),
  location = c("North", "South", "North", "South"),
  year = c(2024, 2024, 2025, 2025),
  water = c("Normal rainfall", "Normal rainfall", "Dry year", "Dry year"))

cfg <- list(
  traits = traits, envs = envs,
  mu = rbind(days_to_heading = c(128, 132, 120, 124), plant_height_cm = c(95, 92, 80, 76),
             spikes_per_m2 = c(380, 350, 300, 280), thousand_kernel_weight_g = c(45, 43, 36, 34),
             grain_yield_t_ha = c(5.2, 4.6, 3.2, 2.8)),
  sd_parent = c(4, 8, 40, 3, 0.5), sd_mut = c(2.5, 7, 30, 2.5, 0.35), env_scale = c(1, 1, 1.2, 1.15),
  Rt = matrix(c(1, .3, -.1, .1, -.1,   .3, 1, -.1, .2, 0,   -.1, -.1, 1, -.3, .6,   .1, .2, -.3, 1, .3,   -.1, 0, .6, .3, 1), 5, 5, byrow = TRUE),
  Re = matrix(c(1, .6, .5, .3,   .6, 1, .3, .5,   .5, .3, 1, .6,   .3, .5, .6, 1), 4, 4, byrow = TRUE),
  parents = paste0("Parent_", LETTERS[1:3]), n_per_parent = 34,
  doses = c(150, 200, 250), dose_scale = c(`150` = 0.7, `200` = 1, `250` = 1.4),
  loss = c(0, -0.2, -0.15, -0.1, -0.2), p_big = 0.10,
  H2_base = c(0.80, 0.75, 0.45, 0.65, 0.45), H2_env = c(1, 0.95, 0.85, 0.70),
  prop_spatial_env = c(0.30, 0.30, 0.40, 0.45), prop_ext_env = c(0.10, 0.10, 0.15, 0.20),
  nblocks = c(2, 2, 2, 2), ncols = rep(16, 4), nrows = 8,       # 2 blocks of 8 x 8 = 128 plots
  # Partially replicated design: parents in every block, 30 mutants twice, 62 mutants once, 10 not tested
  design_nreps = function(e, ids, nb) {
    mut <- grep("^M", ids); n <- rep(nb, length(ids))
    g <- sample(mut); n[g[1:30]] <- 2; n[g[31:92]] <- 1; n[g[93:length(g)]] <- 0
    n
  })
res <- sim_core(cfg)
d <- make_table(res, cfg)

# ---------------------------------------------------------------- Qualitative trait: awn type (per genotype)
awn_parent <- c(Parent_A = "awned", Parent_B = "awned", Parent_C = "awned")
n_mut <- length(res$mut_id)
p_change <- c(`150` = 0.05, `200` = 0.09, `250` = 0.15)[as.character(res$mut_dose)]
awn <- awn_parent[res$mut_parent]
chg <- runif(n_mut) < p_change
awn[chg] <- ifelse(runif(sum(chg)) < 0.6, "short awned", "awnless")
awn_all <- c(awn_parent, setNames(awn, res$mut_id))
d$awn_type <- awn_all[d$genotype]

# ---------------------------------------------------------------- Lodging score (1 to 5), per plot
z <- ave(d$plant_height_cm, d$environment, FUN = function(x) (x - mean(x)) / sd(x))
storm <- c(North_2024 = 0.6, South_2024 = 0, North_2025 = -0.5, South_2025 = -0.5)[d$environment]
lat <- 0.9 * z + storm + rnorm(nrow(d), 0, 0.8)
d$lodging_score <- as.integer(cut(lat, c(-Inf, 0.2, 1.0, 1.8, 2.6, Inf), labels = 1:5))

# ---------------------------------------------------------------- Round like a field book
d$days_to_heading <- round(d$days_to_heading); d$plant_height_cm <- round(pmax(15, d$plant_height_cm))
d$spikes_per_m2 <- round(d$spikes_per_m2); d$thousand_kernel_weight_g <- round(d$thousand_kernel_weight_g, 1)
d$grain_yield_t_ha <- round(pmax(0.2, d$grain_yield_t_ha), 2)
clean <- d

# ---------------------------------------------------------------- Problems
L <- new_log(); n <- nrow(d); tr_all <- c(traits, "lodging_score")
dead <- sample(n, round(0.02 * n))
for (tr in tr_all) { log_add(L, d, dead, tr, "no emergence, plot lost", d[[tr]][dead]); d[[tr]][dead] <- NA }
# hail in South_2025, block B2: real damage, NOT missing (lower yield and fewer spikes in 12 plots)
hail <- setdiff(which(d$environment == "South_2025" & d$block == "B2" & d$row %in% 1:3 & d$column %in% 9:12), dead)
log_add(L, d, hail, "grain_yield_t_ha", "hail damage (real effect, x0.6)", d$grain_yield_t_ha[hail]); d$grain_yield_t_ha[hail] <- round(d$grain_yield_t_ha[hail] * 0.6, 2)
log_add(L, d, hail, "spikes_per_m2", "hail damage (real effect, x0.75)", d$spikes_per_m2[hail]); d$spikes_per_m2[hail] <- round(d$spikes_per_m2[hail] * 0.75)
for (tr in tr_all) {
  ok <- which(!is.na(d[[tr]])); idx <- sample(ok, round(0.03 * length(ok)))
  log_add(L, d, idx, tr, "value not recorded", d[[tr]][idx]); d[[tr]][idx] <- NA
}
out_one <- function(tr, kind, k) {
  ok <- which(!is.na(d[[tr]])); idx <- sample(ok, k); old <- d[[tr]][idx]
  d[[tr]][idx] <<- switch(kind, ten = old * 10, tenth = old / 10, kg = old * 1000, plus = old + 25)
  log_add(L, d, idx, tr, paste("outlier,", kind), old)
}
out_one("grain_yield_t_ha", "kg", 4)           # 4800 (kg/ha) instead of 4.8 (t/ha)
out_one("thousand_kernel_weight_g", "ten", 5)  # 450 instead of 45
out_one("plant_height_cm", "ten", 3)
out_one("days_to_heading", "plus", 6)          # wrong date, 25 days later
out_one("spikes_per_m2", "tenth", 4)
d$grain_yield_t_ha <- round(d$grain_yield_t_ha, 2)

# ---------------------------------------------------------------- Save
cols <- c("environment", "location", "year", "water", "plot", "block", "row", "column", "genotype", "type", "parent",
          "dose_Gy", "awn_type", traits, "lodging_score")
write.csv(d[, cols], "public/wheat_mutant_trials.csv", row.names = FALSE, na = "")
logdf <- do.call(rbind, L$rows)
write.csv(logdf, "answer_key/problems_inserted.csv", row.names = FALSE)
ids <- res$ids; ne <- res$ne; ng <- res$ng
write.csv(data.frame(genotype = rep(ids, times = nt * ne), trait = rep(traits, each = ng * ne),
                     environment = rep(rep(envs$environment, each = ng), times = nt), true_genetic_value = as.vector(res$gv_true)),
          "answer_key/true_genetic_values.csv", row.names = FALSE)
write.csv(data.frame(genotype = ids, parent = c(cfg$parents, res$mut_parent), dose_Gy = c(rep(0, 3), res$mut_dose),
                     awn_type = awn_all[ids]), "answer_key/genotype_list.csv", row.names = FALSE)
write.csv(data.frame(trait = rep(traits, each = ne), environment = rep(envs$environment, nt), target_plot_H2 = res$H2,
                     genetic_variance = res$vg, error_variance = res$varR, prop_spatial = res$ps, prop_extraneous = res$pe),
          "answer_key/simulation_parameters.csv", row.names = FALSE)
saveRDS(clean, "answer_key/clean_table.rds")
message("Done. Rows: ", nrow(d), ". Problems: ", nrow(logdf))
